#!/bin/bash

CSV="/tmp/reporte.csv"

echo "Tablespace,Fichero,Tamaño_bytes" > "$CSV"

sqlplus -s sys/samuoskar@192.168.1.105/pdasir <<EOF >> "$CSV"
SET HEADING OFF
SET FEEDBACK OFF
SET PAGESIZE 0
SELECT tablespace_name || ',' || file_name || ',' || bytes
FROM dba_data_files;
EXIT;
EOF

mail -s "Oskar Henryk Sajek Tuleja" -a "$CSV" "alvaro@alvarogonzalez.no-ip.biz"
