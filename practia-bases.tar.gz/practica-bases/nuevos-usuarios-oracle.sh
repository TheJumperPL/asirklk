#!/bin/bash

export ORACLE_HOME=/opt/oracle-install/
export PATH=$ORACLE_HOME/bin:$PATH
export ORACLE_SID=asir

while IFS= read -r usuario; do
echo "Usuario leído: $usuario"


comprobar_usuario=$(echo "$usuario" | tr '[:lower:]' '[:upper:]')

existe=$(sqlplus -S sys/samuoskar@192.168.1.105/pdasir as sysdba <<EOF
    SET PAGESIZE 0 FEEDBACK OFF HEADING OFF VERIFY OFF
    SELECT COUNT(*) FROM dba_users WHERE username='$comprobar_usuario';
    EXIT;
EOF
)

    if [ "$existe" -ne 0 ]; then
        echo "El usuario $usuario ya existe"
        continue
    fi



contrasena=$RANDOM$RANDOM$RANDOM

sqlplus -S sys/samuoskar@192.168.1.105/pdasir as sysdba <<EOF
SET PAGESIZE 0
SET FEEDBACK OFF
SET HEADING OFF
SET VERIFY OFF
create user $usuario identified by $contrasena;
grant connect, resource to $usuario;
EOF

salida=$?

if [ $salida -eq 0 ]; 
then
	echo "Usuario $usuario creado correctamente con contraseña $contrasena"
else
        echo "Error: el usuario $usuario ya existía o hubo un problema"
fi    
done
