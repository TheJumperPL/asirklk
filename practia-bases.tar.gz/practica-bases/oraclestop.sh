#!/bin/bash

export ORACLE_HOME=/opt/oracle-install/
export PATH=$ORACLE_HOME/bin:$PATH
export ORACLE_SID=asir

ps -ef | grep -v grep | grep ora_pmon_$ORACLE_SID

estado=$?

if [ $estado -ne 0 ];
then
	echo "La base de datos está apagada"
else
	echo "La base de datos está encendida, vamos a apagarla"

echo "apagando el listener"
lsnrctl stop

echo "apagando la base de datos"
sqlplus -S / as sysdba > /dev/null <<EOF
shutdown immediate;
exit;
EOF
echo "Todo apagado"
fi
