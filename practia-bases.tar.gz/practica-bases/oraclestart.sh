#!/bin/bash

export ORACLE_HOME=/opt/oracle-install/
export PATH=$ORACLE_HOME/bin:$PATH
export ORACLE_SID=asir


(ps -ef | grep -v grep | grep pmon)
estado=$?

if [ "$estado" -eq 0 ];
then
    echo "Ya está encendido"
else
    echo "No está encendido, así que vamos a encenderlo"

echo "Encendiendo el listener"
lsnrctl start > /dev/null

echo "Encendiendo la base de datos"

sqlplus -S / as sysdba > /dev/null <<EOF
startup open;
alter pluggable database all open;
exit;
EOF
fi
