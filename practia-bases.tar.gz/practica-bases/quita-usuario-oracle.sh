#!/bin/bash

export ORACLE_HOME=/opt/oracle-install/
export PATH=$ORACLE_HOME/bin:$PATH
export ORACLE_SID=asir


sql=sqlplus -S sys/samuoskar@192.168.1.105/pdasir as sysdba

# Función de ayuda
mostrar_ayuda() {
	echo "Borra o bloquea un usuario de oracle."
	echo
	echo "Uso: $0 <usuario>"
	echo "     $0 --drop <usuario>"
	exit 1
}


if [ $# -eq 0 ]; then
	mostrar_ayuda
fi


bloquear_usuario() {
local usuario=$1
$sql <<EOF
WHENEVER SQLERROR EXIT 1
DECLARE
    v_count NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_count FROM dba_users WHERE username=UPPER('$usuario');
    IF v_count = 0 THEN
        dbms_output.put_line('El usuario $usuario no existe.');
        RAISE_APPLICATION_ERROR(-20001, 'Usuario no encontrado');
    ELSE
        EXECUTE IMMEDIATE 'ALTER USER $usuario ACCOUNT LOCK';
        dbms_output.put_line('Usuario $usuario bloqueado.');
    END IF;
END;
/
EXIT;
EOF
}

borrar_usuario() {
local usuario=$1
$sql <<EOF
WHENEVER SQLERROR EXIT 1
DECLARE
    v_count NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_count FROM dba_users WHERE username=UPPER('$usuario');
    IF v_count = 0 THEN
        dbms_output.put_line('El usuario $usuario no existe.');
        RAISE_APPLICATION_ERROR(-20001, 'Usuario no encontrado');
    ELSE
        EXECUTE IMMEDIATE 'DROP USER $usuario CASCADE';
        dbms_output.put_line('Usuario $usuario borrado.');
    END IF;
END;
/
EXIT;
EOF
}


if [ "$1" = "--drop" ]; then
if [ $# -ne 2 ]; then
	mostrar_ayuda
fi
	borrar_usuario "$2"
	exit $?
else
if [ $# -ne 1 ]; then
        mostrar_ayuda
fi
        bloquear_usuario "$1"
        exit $?
fi

